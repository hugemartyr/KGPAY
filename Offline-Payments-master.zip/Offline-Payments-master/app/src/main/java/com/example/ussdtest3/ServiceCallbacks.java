package com.example.ussdtest3;

public interface ServiceCallbacks {
    void doSomething(String status,int resultCode);
}
